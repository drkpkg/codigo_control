ImpuestosInternosHelper
=======================

Libreria para generacion de codigos de control acorde a la Version 7 de Impuestos y genera imagenes de los QR en base64

Hecho con mucho cafe y sueño en mis ratos libres.

